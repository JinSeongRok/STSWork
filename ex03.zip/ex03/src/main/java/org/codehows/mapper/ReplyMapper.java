package org.codehows.mapper;

import org.codehows.domain.ReplyVO;

public interface ReplyMapper {

	public int insert(ReplyVO vo);
}
